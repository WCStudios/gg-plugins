-- =============================================================================
-- Refresh GG LUTs
-- Scans the G&G LUT folders and rebuilds the LUT dropdowns inside GG_GradePro.
--
-- HOW TO USE
--   1. Drop new .cube files into ANY of:
--        /Library/Application Support/Blackmagic Design/DaVinci Resolve/LUT/
--          G&G Camera Conversion/
--          G&G LOG Conversion/
--          G&G Creative Looks/
--      (or the same paths under ~/Library/... if your team uses user library)
--   2. In Resolve, switch to the Fusion page.
--   3. From the Scripts menu (above the timeline panel), choose:
--        Utility → Refresh GG LUTs
--   4. Run Fusion → File → Reload Macros   (or restart Resolve)
--   5. Any newly-applied GG_GradePro instance will see the new LUTs.
--      Existing instances on your timeline keep their current settings.
--
-- INSTALL
--   Copy this file to:
--     ~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Scripts/Utility/Refresh GG LUTs.lua
--
-- KNOWN LIMITATION
--   Built-in presets (MN Hockey, Tradition, Walser) reference Creative LUTs by
--   numeric index. If you add a LUT that comes alphabetically BEFORE one of
--   those preset LUTs, the indices will shift and presets will apply the wrong
--   LUT. Re-save the preset (Save Current button) to lock it back in.
-- =============================================================================

local HOME = os.getenv("HOME") or ""

-- Macro can live in either library. Prefer system (where the team installs).
local MACRO_CANDIDATES = {
  "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Templates/Edit/Effects/Grain & Gate/Color + Texture/GG_GradePro.setting",
  HOME .. "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Templates/Edit/Effects/Grain & Gate/Color + Texture/GG_GradePro.setting",
  "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Templates/Edit/Effects/Grain & Gate/GG_GradePro.setting",
  HOME .. "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Templates/Edit/Effects/Grain & Gate/GG_GradePro.setting",
}

local function find_macro_path()
  for _, p in ipairs(MACRO_CANDIDATES) do
    local f = io.open(p, "r")
    if f then f:close() return p end
  end
  return nil
end

local MACRO_PATH = find_macro_path()

-- Search order: system library first (team installs), then user library
local LIB_ROOTS = {
  "/Library/Application Support/Blackmagic Design/DaVinci Resolve/LUT",
  HOME .. "/Library/Application Support/Blackmagic Design/DaVinci Resolve/LUT",
}

local CATEGORIES = {
  { selector = "LOGSelector",      file_tool = "FileLUT1_1", folder = "G&G LOG Conversion"    },
  { selector = "CameraSelector",   file_tool = "FileLUT1",   folder = "G&G Camera Conversion" },
  { selector = "CreativeSelector", file_tool = "FileLUT2",   folder = "G&G Creative Looks"    },
}

-- ----------------------------------------------------------------------------
-- List .cube files in a directory, sorted alphabetically (case-insensitive)
-- ----------------------------------------------------------------------------
local function list_cubes(dir)
  local files = {}
  local cmd = string.format('ls -1 %q 2>/dev/null', dir)
  local h = io.popen(cmd)
  if h then
    for line in h:lines() do
      if line:lower():match("%.cube$") then
        files[#files + 1] = line
      end
    end
    h:close()
  end
  table.sort(files, function(a, b) return a:lower() < b:lower() end)
  return files
end

-- ----------------------------------------------------------------------------
-- Find which library root has the category folder; prefer the one with files
-- Returns: absolute_dir, files_table
-- ----------------------------------------------------------------------------
local function find_category(folder)
  for _, root in ipairs(LIB_ROOTS) do
    local dir = root .. "/" .. folder
    local files = list_cubes(dir)
    if #files > 0 then return dir, files end
  end
  return LIB_ROOTS[1] .. "/" .. folder, {}
end

-- ----------------------------------------------------------------------------
-- Escape a single-quoted Lua string literal that will live inside an outer
-- double-quoted Fusion Input value. We only need to worry about ' inside paths.
-- ----------------------------------------------------------------------------
local function esc_squote(s)
  return (s:gsub("'", "\\'"))
end

-- Strip .cube extension for the dropdown display name
local function display_name(filename)
  return (filename:gsub("%.[cC][uU][bB][eE]$", ""))
end

-- Escape display name for the macro file's double-quoted string
local function esc_dquote(s)
  return (s:gsub("\\", "\\\\"):gsub('"', '\\"'))
end

-- ----------------------------------------------------------------------------
-- Build the OnChange Lua source for a selector (raw, no outer quoting)
-- ----------------------------------------------------------------------------
local function build_onchange(selector, file_tool, dir, files)
  local pieces = { "[1] = ''" }
  for i, f in ipairs(files) do
    pieces[#pieces + 1] = string.format("[%d] = '%s/%s'", i + 1, esc_squote(dir), esc_squote(f))
  end
  local paths_lua = "{" .. table.concat(pieces, ", ") .. "}"

  local tail
  if selector == "CreativeSelector" then
    tail = string.format(
      "%s:SetInput('LUTFile', paths[v+1]) GradeCtrl:SetInput('CreativeIntensity', 0.75)",
      file_tool)
  else
    tail = string.format(
      "%s:SetInput('LUTFile', paths[v+1]) local b = %s:GetInput('Blend') or 0 if b == 0 then %s:SetInput('Blend', 1) end",
      file_tool, file_tool, file_tool)
  end

  return string.format(
    "pcall(function() local v = GradeCtrl:GetInput('%s') or 0 if v == 0 then %s:SetInput('Blend', 0) else local paths = %s %s end end)",
    selector, file_tool, paths_lua, tail)
end

-- ----------------------------------------------------------------------------
-- Build the CCS_AddString block (with leading "None") at the given indent
-- ----------------------------------------------------------------------------
local function build_ccs_block(files, indent)
  local lines = { indent .. '{ CCS_AddString = "None", },' }
  for _, f in ipairs(files) do
    lines[#lines + 1] = indent .. '{ CCS_AddString = "' .. esc_dquote(display_name(f)) .. '", },'
  end
  return table.concat(lines, "\n")
end

-- ----------------------------------------------------------------------------
-- Replace INPS_ExecuteOnChange = "...GetInput('SELECTOR')..." with new value
-- ----------------------------------------------------------------------------
local function lua_escape_pattern(s)
  return (s:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1"))
end

local function replace_onchange(text, selector, new_value)
  local pat = 'INPS_ExecuteOnChange = "[^"]*GetInput%(\'' .. lua_escape_pattern(selector) .. '\'%)[^"]*"'
  local replacement = ('INPS_ExecuteOnChange = "' .. new_value .. '"'):gsub("%%", "%%%%")
  return text:gsub(pat, replacement, 1)
end

-- ----------------------------------------------------------------------------
-- Replace the consecutive { CCS_AddString = "..." }, lines that follow each
-- selector's UserControl opening line
-- ----------------------------------------------------------------------------
local function replace_ccs_block(text, selector, new_block)
  local open_marker = "\n\t\t\t\t\t\t" .. selector .. " = {"
  local open_pos = text:find(open_marker, 1, true)
  if not open_pos then return text, 0 end

  local first_ccs = text:find('{ CCS_AddString = "', open_pos, true)
  if not first_ccs then return text, 0 end

  -- Walk back to start of the first CCS line
  local line_start = first_ccs
  while line_start > 1 and text:sub(line_start - 1, line_start - 1) ~= "\n" do
    line_start = line_start - 1
  end

  -- Walk forward consuming consecutive CCS_AddString lines
  local p = line_start
  local last_end = p - 1
  while true do
    local nl = text:find("\n", p, true)
    if not nl then break end
    local line = text:sub(p, nl - 1)
    if line:match("^%s*{%s*CCS_AddString%s*=%s*\"") then
      last_end = nl
      p = nl + 1
    else
      break
    end
  end

  return text:sub(1, line_start - 1) .. new_block .. "\n" .. text:sub(last_end + 1), 1
end

-- ----------------------------------------------------------------------------
-- Update Prev/Next LUT wraparound bounds to current Creative LUT count
-- ----------------------------------------------------------------------------
local function update_prev_next_bounds(text, n_creative)
  if n_creative < 1 then n_creative = 1 end
  local ns = tostring(n_creative)
  text = text:gsub("(GetInput%('CreativeSelector'%) or 0 if v <= 1 then v = )%d+", "%1" .. ns, 1)
  text = text:gsub("(GetInput%('CreativeSelector'%) or 0 if v >= )%d+( then v = 1)",
                   "%1" .. ns .. "%2", 1)
  return text
end

-- ----------------------------------------------------------------------------
-- Parse the CURRENT CCS_AddString list for a selector from the macro text.
-- Returns an array indexed 1..N (the "None" entry is removed) so that the
-- result matches the combo's stored numeric values for that selector.
-- This captures the BEFORE-rewrite ordering, which we use to migrate any
-- old index-only user presets to name-based ones.
-- ----------------------------------------------------------------------------
local function parse_combo_names(text, selector)
  local open_marker = "\n\t\t\t\t\t\t" .. selector .. " = {"
  local open_pos = text:find(open_marker, 1, true)
  if not open_pos then return {} end
  local first_ccs = text:find('{ CCS_AddString = "', open_pos, true)
  if not first_ccs then return {} end

  local line_start = first_ccs
  while line_start > 1 and text:sub(line_start - 1, line_start - 1) ~= "\n" do
    line_start = line_start - 1
  end

  local names = {}
  local p = line_start
  while true do
    local nl = text:find("\n", p, true)
    if not nl then break end
    local line = text:sub(p, nl - 1)
    local nm = line:match('{%s*CCS_AddString%s*=%s*"(.-)"%s*,?%s*}%s*,?%s*$')
    if nm then
      table.insert(names, nm)
      p = nl + 1
    else
      break
    end
  end
  if names[1] == "None" then table.remove(names, 1) end
  return names
end

-- ----------------------------------------------------------------------------
-- Serialize a Lua table for the user-presets file (matches SavePreset_Script)
-- ----------------------------------------------------------------------------
local function ser_preset_table(t, ind)
  ind = ind or ""
  local lines = { "{" }
  for k, v in pairs(t) do
    local kk
    if type(k) == "string" then kk = '["' .. k .. '"]'
    else kk = "[" .. tostring(k) .. "]" end
    if type(v) == "table" then
      table.insert(lines, ind .. "  " .. kk .. " = " .. ser_preset_table(v, ind .. "  ") .. ",")
    elseif type(v) == "string" then
      table.insert(lines, ind .. "  " .. kk .. " = " .. string.format("%q", v) .. ",")
    elseif type(v) == "number" or type(v) == "boolean" then
      table.insert(lines, ind .. "  " .. kk .. " = " .. tostring(v) .. ",")
    end
  end
  table.insert(lines, ind .. "}")
  return table.concat(lines, "\n")
end

-- ----------------------------------------------------------------------------
-- Migrate user-saved presets from raw indices to name-based references.
-- Run BEFORE the macro is rewritten so the lists reflect the ordering the
-- user's presets were saved under. Idempotent: presets that already have
-- *_name fields are left alone; presets that pointed at "None" (idx 0) are
-- left alone too.
-- ----------------------------------------------------------------------------
local function migrate_user_presets(macro_text)
  local home = os.getenv("HOME") or ""
  local presets_path = home ..
    "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Templates/Edit/Effects/Grain & Gate/GG_GradePro_UserPresets.lua"

  local fr = io.open(presets_path, "r")
  if not fr then return 0, 0, presets_path end
  fr:close()

  local ok, presets = pcall(dofile, presets_path)
  if not (ok and type(presets) == "table") then return 0, 0, presets_path end

  local lists = {
    camera   = parse_combo_names(macro_text, "CameraSelector"),
    log      = parse_combo_names(macro_text, "LOGSelector"),
    creative = parse_combo_names(macro_text, "CreativeSelector"),
  }
  local cat_map = {
    CameraSelector   = "camera",
    LOGSelector      = "log",
    CreativeSelector = "creative",
  }

  local migrated_fields = 0
  local touched_slots = 0
  for _, slot in pairs(presets) do
    if type(slot) == "table" then
      local touched_this_slot = false
      for sel_key, cat in pairs(cat_map) do
        local name_key = sel_key .. "_name"
        local idx = slot[sel_key]
        if type(idx) == "number" and idx > 0 and slot[name_key] == nil then
          local name = lists[cat][idx]
          if name then
            slot[name_key] = name
            migrated_fields = migrated_fields + 1
            touched_this_slot = true
          end
        end
      end
      if touched_this_slot then touched_slots = touched_slots + 1 end
    end
  end

  if migrated_fields == 0 then return 0, 0, presets_path end

  local fw = io.open(presets_path, "w")
  if fw then
    fw:write("return " .. ser_preset_table(presets))
    fw:close()
  end
  return migrated_fields, touched_slots, presets_path
end

-- ============================================================================
-- MAIN
-- ============================================================================
print("================ Refresh GG LUTs ================")
if not MACRO_PATH then
  print("ERROR: Could not find GG_GradePro.setting in either library:")
  for _, p in ipairs(MACRO_CANDIDATES) do print("  " .. p) end
  return
end
print("Macro: " .. MACRO_PATH)
print("")

local fr = io.open(MACRO_PATH, "r")
if not fr then
  print("ERROR: Cannot open macro file. Aborting.")
  return
end
local text = fr:read("*a")
fr:close()

-- IMPORTANT: migration must run BEFORE we rewrite the macro, so the combo
-- name lists we parse reflect the ordering that the user's presets were
-- originally saved under.
local mig_fields, mig_slots, mig_path = migrate_user_presets(text)
if mig_fields > 0 then
  print(string.format("Migrated %d LUT reference(s) across %d preset slot(s) to name-based lookup.",
    mig_fields, mig_slots))
  print("  " .. mig_path)
  print("")
else
  print("(No user presets needed migration.)")
  print("")
end

local creative_count = 0
local total_changes = 0
local manifest = { camera = {}, log = {}, creative = {} }
local cat_to_manifest_key = {
  CameraSelector   = "camera",
  LOGSelector      = "log",
  CreativeSelector = "creative",
}

for _, cat in ipairs(CATEGORIES) do
  local dir, files = find_category(cat.folder)
  print(string.format("• %s", cat.folder))
  print(string.format("    Source: %s", dir))
  print(string.format("    Found:  %d .cube file(s)", #files))
  for _, f in ipairs(files) do print("      - " .. f) end

  local new_oc  = build_onchange(cat.selector, cat.file_tool, dir, files)
  local new_ccs = build_ccs_block(files, "\t\t\t\t\t\t")  -- 6 tabs

  local oc_text, oc_n = replace_onchange(text, cat.selector, new_oc)
  local cc_text, cc_n = replace_ccs_block(oc_text, cat.selector, new_ccs)
  text = cc_text
  total_changes = total_changes + oc_n + cc_n
  print(string.format("    OnChange replaced: %s    Combo entries replaced: %s",
    oc_n > 0 and "yes" or "NO ***", cc_n > 0 and "yes" or "NO ***"))
  print("")

  if cat.selector == "CreativeSelector" then creative_count = #files end

  -- Build manifest entry: alphabetical name list (matches combo index 1..N; index 0 = None)
  local mkey = cat_to_manifest_key[cat.selector]
  if mkey then
    local names = {}
    for _, f in ipairs(files) do
      table.insert(names, display_name(f))
    end
    manifest[mkey] = names
  end
end

if creative_count > 0 then
  text = update_prev_next_bounds(text, creative_count)
  print(string.format("Prev/Next LUT cycle bounds updated to wrap at %d.", creative_count))
end

if total_changes == 0 then
  print("WARNING: No changes were made. Verify GG_GradePro.setting is present.")
  return
end

-- Write sidecar manifest next to the macro file so preset scripts can resolve
-- LUT name -> current combo index regardless of LUT order changes.
local manifest_path = MACRO_PATH:gsub("/GG_GradePro%.setting$", "/GG_GradePro_LUTManifest.lua")
do
  local fm, mer = io.open(manifest_path, "w")
  if fm then
    local function ser(t)
      local out = { "{" }
      for k, v in pairs(t) do
        if type(v) == "table" then
          local arr = { "{" }
          for _, name in ipairs(v) do
            table.insert(arr, "    " .. string.format("%q", name) .. ",")
          end
          table.insert(arr, "  }")
          table.insert(out, "  " .. k .. " = " .. table.concat(arr, "\n") .. ",")
        end
      end
      table.insert(out, "}")
      return table.concat(out, "\n")
    end
    fm:write("return " .. ser(manifest) .. "\n")
    fm:close()
    print("Wrote manifest: " .. manifest_path)
  else
    print("WARNING: Could not write manifest file: " .. tostring(mer))
  end
end

local fw, err = io.open(MACRO_PATH, "w")
if not fw then
  print("ERROR: Cannot write macro file: " .. tostring(err))
  return
end
fw:write(text)
fw:close()

print("")
print("================ Done ================")
print("Macro saved.")
print("")
print("Next step:  Fusion menu → File → Reload Macros")
print("            (or restart Resolve)")
print("")
print("Existing GradePro instances on your timeline keep their settings;")
print("only newly-applied instances will see the refreshed LUT list.")
