return {
  creative = {
    "Avondale",
    "Belmont",
    "G&G - Haze",
    "G&G - Lakeshore",
    "G&G - Pine",
    "Harbor_heavy",
    "Hestia 03",
    "Montrose",
    "North Park",
    "Ravenswood",
  },
  log = {
    "Apple LOG to Rec709",
    "Sony Slog3 to Rec709",
    "WC_FX5_AmberDensity_SLog3_to_Rec709",
  },
  camera = {
    "CM Conversion (a7iv to Fx3)",
    "CM Conversion (Dlog to Slog3)",
    "CM Conversion (DlogM to Slog3)",
  },
}
