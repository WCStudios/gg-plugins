return {
  camera = {
    "CM Conversion (a7iv to Fx3)",
    "CM Conversion (Clog to Slog3)",
    "CM Conversion (Clog3 to Slog3)",
    "CM Conversion (Dlog to Slog3)",
    "CM Conversion (DlogM to Slog3)",
    "CM Conversion (G-Flat to Slog3)",
    "CM Conversion (G-LOG to Slog3)",
  },
  creative = {
    "G&G - Birch",
    "G&G - Cedar",
    "G&G - Harbor",
    "G&G - Haze",
    "G&G - Lakeshore",
    "G&G - Pine",
  },
  log = {
    "Apple LOG to Rec709",
    "Sony Slog3 to Rec709",
    "WC_Cedar_SLog3_to_Rec709",
    "WC_FX5_AmberDensity_SLog3_to_Rec709",
  },
}
