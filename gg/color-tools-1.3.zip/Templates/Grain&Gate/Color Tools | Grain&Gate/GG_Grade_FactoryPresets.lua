return { version = 2, list = {} }
