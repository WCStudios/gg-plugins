return {
  log = {
    "Apple LOG to Rec709",
    "Sony Slog3 to Rec709",
    "WC_FX5_AmberDensity_SLog3_to_Rec709",
  },
  camera = {
    "CM Conversion (a7iv to Fx3)",
    "CM Conversion (Clog to Slog3)",
    "CM Conversion (Dlog to Slog3)",
    "CM Conversion (DlogM to Slog3)",
  },
  creative = {
    "Avondale",
    "Belmont",
    "Birch",
    "Birch_strong",
    "G&G - Birch",
    "G&G - Haze",
    "G&G - Lakeshore",
    "G&G - Pine",
    "Harbor_heavy",
    "Hestia 03",
    "Montrose",
    "North Park",
    "Ravenswood",
  },
}
